# Model karyawan
# Create your models here.
from __future__ import unicode_literals
from django.utils.encoding import python_2_unicode_compatible

from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Operator (models.Model):
    nama = models.CharField(max_length=100)
    
    def __str__(self):
        return self.nama


class Jual(models.Model):
    HARGA_CHOICES = (
        ('goceng', 'Rp.5.000'),
        ('ceban', 'Rp.10.000'),
        ('jigo', 'Rp.25.000'),
        ('gocap', 'Rp.50.000'),
        ('cepe', 'Rp.100.000'),
    )

    
    nama_petugas = models.CharField(max_length=100)
    nominal = models.CharField(max_length=10, choices=HARGA_CHOICES)
    operator = models.ForeignKey(Operator, on_delete=models.CASCADE)
    no_telepon = models.CharField(max_length=30, blank=True)
    

    def __str__(self):
        return self.nama_petugas

