# Admin Karyawan
# Register your models here.
from django.contrib import admin
from counter.models import *

# Register your models here.
class OperatorAdmin (admin.ModelAdmin):
    list_display = ['nama']
    list_filter = ()
    search_fields = ['nama']
    list_per_page = 25

admin.site.register(Operator, OperatorAdmin)


class JualAdmin (admin.ModelAdmin):
    list_display = ['nama_petugas',  'nominal', 'operator', 'no_telepon']
    list_filter = ()
    search_fields = ['no_telepon']
    list_per_page = 25

admin.site.register(Jual, JualAdmin)

